README

Course: cs400
Semester: spring 2020
Project name: Milk Weight
Team Members:
1. Shivish Makkar, 002, and makkar@wisc.edu
2. Sreenivas Krishna Nair, 002, and snair25@wisc.edu
3. Sion Wilks-Boguszewicz, 001, and wilksbogusze@wisc.edu
4. Jason Oliveira, 002, and jroliveira@wisc.edu


Which team members were on same xteam together?
Sreenivas and Jason

Future work: 
add option for user to view different reports as a bar graph or a pie chart

Other notes or comments to the grader: We were unable to get the css style sheet to work with the jar




